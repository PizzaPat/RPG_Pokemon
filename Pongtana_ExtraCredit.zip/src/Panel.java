import javax.swing.*;
import java.io.File;

public class Panel extends JPanel{
    public Panel(Player ash, Map map, File saved){

    }
}
