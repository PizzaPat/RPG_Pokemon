public interface Water {
    public static final int type = 1;
    public static String typeMenu = "1. Water Gun   2. Bubble Beam   3. Waterfall";
    public int waterGun();
    public int bubbleBeam();
    public int waterFall();
}
