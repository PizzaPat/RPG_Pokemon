public interface Grass {
    public static final int type = 2;
    public static String typeMenu = "1. Vine Whip   2. Razor Leaf   3. Solar Beam";
    public int vineWhip();
    public int razorLeaf();
    public int solarBeam();
}
